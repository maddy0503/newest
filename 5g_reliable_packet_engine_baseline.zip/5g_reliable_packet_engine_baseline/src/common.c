/* common.c - status code descriptions. */
#include "common.h"

const char *status_to_string(status_t status)
{
    const char *text = "unknown error";

    switch (status) {
    case STATUS_OK:                 text = "success"; break;
    case STATUS_ERR_NULL:           text = "null pointer argument"; break;
    case STATUS_ERR_RANGE:          text = "value out of range"; break;
    case STATUS_ERR_FORMAT:         text = "invalid format or characters"; break;
    case STATUS_ERR_DUPLICATE:      text = "duplicate key"; break;
    case STATUS_ERR_NOT_FOUND:      text = "not found"; break;
    case STATUS_ERR_EMPTY:          text = "container is empty"; break;
    case STATUS_ERR_FULL:           text = "container or window is full"; break;
    case STATUS_ERR_NOMEM:          text = "out of memory"; break;
    case STATUS_ERR_IO:             text = "I/O error or end of input"; break;
    case STATUS_ERR_STATE:          text = "inconsistent internal state"; break;
    case STATUS_ERR_SAME_ENDPOINT:  text = "source and destination are identical"; break;
    case STATUS_ERR_MAX_RETRIES:    text = "maximum retransmissions exceeded"; break;
    default:                        break;
    }
    return text;
}
