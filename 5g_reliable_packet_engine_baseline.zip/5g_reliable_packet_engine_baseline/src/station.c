/* station.c - station record validation and printing. */
#include <stdio.h>
#include <string.h>
#include "station.h"
#include "bst.h"

static bool is_allowed_char(char c)
{
    return ((c >= 'A') && (c <= 'Z')) || ((c >= 'a') && (c <= 'z')) ||
           ((c >= '0') && (c <= '9')) || (c == ' ') || (c == '-') ||
           (c == '_') || (c == '.');
}

status_t station_validate_text(const char *text, size_t buffer_size)
{
    status_t rc = STATUS_OK;

    if ((text == NULL) || (buffer_size < 2U)) {
        rc = STATUS_ERR_NULL;
    } else {
        size_t i = 0U;
        bool terminated = false;

        /* Bounded scan: never reads at or beyond buffer_size bytes. */
        while ((i < buffer_size) && (!terminated) && (rc == STATUS_OK)) {
            if (text[i] == '\0') {
                terminated = true;
            } else if (!is_allowed_char(text[i])) {
                rc = STATUS_ERR_FORMAT;
            } else {
                i++;
            }
        }
        if (rc != STATUS_OK) {
            /* illegal character: already reported */
        } else if (!terminated) {
            rc = STATUS_ERR_RANGE;         /* too long for the destination */
        } else if (i == 0U) {
            rc = STATUS_ERR_FORMAT;        /* empty */
        } else if ((text[0] == ' ') || (text[i - 1U] == ' ')) {
            rc = STATUS_ERR_FORMAT;        /* leading/trailing blank */
        } else {
            /* valid text */
        }
    }
    return rc;
}

status_t station_validate_id(station_id_t id)
{
    return ((id >= STATION_ID_MIN) && (id <= STATION_ID_MAX)) ? STATUS_OK
                                                              : STATUS_ERR_RANGE;
}

status_t station_validate_numbers(uint32_t distance_km, uint32_t fare,
                                  uint32_t platform)
{
    bool bad = (distance_km > STATION_DISTANCE_MAX) ||
               (fare > STATION_FARE_MAX) ||
               (platform < STATION_PLATFORM_MIN) ||
               (platform > STATION_PLATFORM_MAX);

    return bad ? STATUS_ERR_RANGE : STATUS_OK;
}

status_t station_validate(const station_t *station)
{
    status_t rc;

    if (station == NULL) {
        rc = STATUS_ERR_NULL;
    } else {
        rc = station_validate_id(station->id);
        if (rc == STATUS_OK) {
            rc = station_validate_text(station->name, STATION_NAME_MAX);
        }
        if (rc == STATUS_OK) {
            rc = station_validate_numbers(station->distance_km, station->fare,
                                          station->platform);
        }
        if (rc == STATUS_OK) {
            rc = station_validate_text(station->type, STATION_TYPE_MAX);
        }
    }
    return rc;
}

status_t station_init(station_t *station, station_id_t id, const char *name,
                      uint32_t distance_km, uint32_t fare, uint32_t platform,
                      const char *type)
{
    status_t rc;

    if (station == NULL) {
        rc = STATUS_ERR_NULL;
    } else {
        rc = station_validate_id(id);
        if (rc == STATUS_OK) {
            rc = station_validate_text(name, STATION_NAME_MAX);
        }
        if (rc == STATUS_OK) {
            rc = station_validate_numbers(distance_km, fare, platform);
        }
        if (rc == STATUS_OK) {
            rc = station_validate_text(type, STATION_TYPE_MAX);
        }
        if (rc == STATUS_OK) {
            /* Both strings are validated to be NUL-terminated in their buffers. */
            size_t name_len = strlen(name);
            size_t type_len = strlen(type);

            (void)memset(station, 0, sizeof(*station));
            station->id = id;
            station->distance_km = distance_km;
            station->fare = fare;
            station->platform = platform;
            (void)memcpy(station->name, name, name_len + 1U);
            (void)memcpy(station->type, type, type_len + 1U);
        }
    }
    return rc;
}

status_t station_validate_endpoints(const struct bst *tree, station_id_t src,
                                    station_id_t dst, station_id_t *bad_id)
{
    status_t rc = STATUS_OK;
    station_id_t bad = 0U;

    if (tree == NULL) {
        rc = STATUS_ERR_NULL;
    } else if (station_validate_id(src) != STATUS_OK) {
        bad = src;
        rc = STATUS_ERR_RANGE;
    } else if (station_validate_id(dst) != STATUS_OK) {
        bad = dst;
        rc = STATUS_ERR_RANGE;
    } else if (src == dst) {
        bad = src;
        rc = STATUS_ERR_SAME_ENDPOINT;
    } else if (bst_search(tree, src) == NULL) {
        bad = src;
        rc = STATUS_ERR_NOT_FOUND;
    } else if (bst_search(tree, dst) == NULL) {
        bad = dst;
        rc = STATUS_ERR_NOT_FOUND;
    } else {
        /* both endpoints valid */
    }
    if (bad_id != NULL) {
        *bad_id = bad;
    }
    return rc;
}

void station_print(const station_t *station)
{
    if (station != NULL) {
        (void)printf("  %-6u %-31s %7u km  %7u  %8u  %s\n",
                     (unsigned)station->id, station->name,
                     (unsigned)station->distance_km, (unsigned)station->fare,
                     (unsigned)station->platform, station->type);
    }
}
