/* station.h - telecom station record and its validation rules. */
#ifndef STATION_H
#define STATION_H

#include "common.h"

#define STATION_NAME_MAX   32U      /* buffer size incl. NUL -> 31 chars */
#define STATION_TYPE_MAX   16U      /* buffer size incl. NUL -> 15 chars */
#define STATION_ID_MIN     1U
#define STATION_ID_MAX     99999U
#define STATION_DISTANCE_MAX 100000U /* kilometres */
#define STATION_FARE_MAX     100000U /* fare in whole currency units */
#define STATION_PLATFORM_MIN 1U
#define STATION_PLATFORM_MAX 99U

typedef uint32_t station_id_t;

typedef struct {
    station_id_t id;                 /* BST key                      */
    char         name[STATION_NAME_MAX];
    uint32_t     distance_km;
    uint32_t     fare;               /* whole currency units, 0..FARE_MAX */
    uint32_t     platform;           /* platform number, 1..PLATFORM_MAX  */
    char         type[STATION_TYPE_MAX]; /* e.g. "gNodeB", "Core"    */
} station_t;

struct bst; /* forward declaration, see bst.h */

/* Allowed characters: A-Z a-z 0-9 space - _ .  No leading/trailing space. */
status_t station_validate_text(const char *text, size_t buffer_size);
status_t station_validate_id(station_id_t id);
status_t station_validate(const station_t *station);

/* Range-checks the numeric attributes: distance, fare and platform. */
status_t station_validate_numbers(uint32_t distance_km, uint32_t fare,
                                  uint32_t platform);

/* Validates every field, then fills *station (zero-initialised first). */
status_t station_init(station_t *station, station_id_t id, const char *name,
                      uint32_t distance_km, uint32_t fare, uint32_t platform,
                      const char *type);

/* Checks both IDs are in range, different, and present in the tree.
 * *bad_id (optional) receives the offending ID, or 0 if none. */
status_t station_validate_endpoints(const struct bst *tree, station_id_t src,
                                    station_id_t dst, station_id_t *bad_id);

void station_print(const station_t *station);

#endif /* STATION_H */
