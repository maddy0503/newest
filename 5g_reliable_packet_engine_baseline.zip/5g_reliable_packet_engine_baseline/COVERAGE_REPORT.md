# Coverage Report - BASELINE variant (measured in this workspace)

Command: `make coverage` using GCC/gcov with `-O0 --coverage`, running three C test binaries
(`test_bst`, `test_station`, `test_sliding_window`). The logger and extended regression suites are not run in this variant.

| File | Lines % | Branch % | Function % |
|---|---:|---:|---:|
| `src/common.c` | 100.00 | 100.00 | 100.0 (1/1) |
| `src/bst.c` | 98.00 | 86.27 | 100.0 (12/12) |
| `src/station.c` | 100.00 | 100.00 | 100.0 (8/8) |
| `src/packet.c` | 100.00 | 90.91 | 100.0 (13/13) |
| `src/sliding_window.c` | 97.84 | 84.75 | 100.0 (22/22) |
| `src/storage.c` | 94.17 | 89.77 | 100.0 (6/6) |
| `src/input.c` | 100.00 | 85.58 | 100.0 (4/4) |
| `src/logger.c` | 21.74 | 9.86 | 30.8 (4/13) |
| **TOTAL** | **89.3** | **81.4** | **88.6** |

Optimised version for comparison: 97.8 % line / 92.5 % branch / 100 % function.
