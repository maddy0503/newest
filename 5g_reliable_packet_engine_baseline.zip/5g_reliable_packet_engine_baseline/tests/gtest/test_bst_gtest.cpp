// GoogleTest unit tests for the BST station manager (C code wrapped in extern "C").
#include <gtest/gtest.h>
#include <vector>

extern "C" {
#include "bst.h"
}

namespace {

void collect_cb(const station_t *s, void *ctx)
{
    static_cast<std::vector<station_id_t> *>(ctx)->push_back(s->id);
}

class BstTest : public ::testing::Test {
protected:
    void SetUp() override { bst_init(&tree_); }
    void TearDown() override { bst_destroy(&tree_); }

    status_t add(station_id_t id)
    {
        station_t s;
        EXPECT_EQ(STATUS_OK, station_init(&s, id, "Node", 10U, 100U, 1U, "gNodeB"));
        return bst_insert(&tree_, &s);
    }

    bst_t tree_;
};

TEST_F(BstTest, InsertAndSearch)
{
    EXPECT_EQ(STATUS_OK, add(500U));
    const station_t *s = bst_search(&tree_, 500U);
    ASSERT_NE(nullptr, s);
    EXPECT_EQ(500U, s->id);
    EXPECT_EQ(nullptr, bst_search(&tree_, 501U));
}

TEST_F(BstTest, DuplicateRejected)
{
    EXPECT_EQ(STATUS_OK, add(10U));
    EXPECT_EQ(STATUS_ERR_DUPLICATE, add(10U));
    EXPECT_EQ(1U, tree_.count);
}

TEST_F(BstTest, InorderIsSorted)
{
    for (station_id_t id : {500U, 250U, 750U, 120U, 300U, 600U, 900U}) {
        ASSERT_EQ(STATUS_OK, add(id));
    }
    std::vector<station_id_t> out;
    ASSERT_EQ(STATUS_OK, bst_inorder(&tree_, collect_cb, &out));
    EXPECT_EQ((std::vector<station_id_t>{120, 250, 300, 500, 600, 750, 900}), out);
}

TEST_F(BstTest, UpdateChangesFields)
{
    ASSERT_EQ(STATUS_OK, add(7U));
    EXPECT_EQ(STATUS_OK, bst_update(&tree_, 7U, "Renamed", 99U, 100U, 1U, "Core"));
    const station_t *s = bst_search(&tree_, 7U);
    ASSERT_NE(nullptr, s);
    EXPECT_STREQ("Renamed", s->name);
    EXPECT_EQ(99U, s->distance_km);
    EXPECT_STREQ("Core", s->type);
    EXPECT_EQ(STATUS_ERR_NOT_FOUND, bst_update(&tree_, 8U, "X", 1U, 100U, 1U, "Y"));
}

TEST_F(BstTest, UpdateChangesFareAndPlatform)
{
    ASSERT_EQ(STATUS_OK, add(7U));
    EXPECT_EQ(STATUS_OK, bst_update(&tree_, 7U, "Renamed", 99U, 250U, 9U, "Core"));
    const station_t *s = bst_search(&tree_, 7U);
    ASSERT_NE(nullptr, s);
    EXPECT_EQ(250U, s->fare);
    EXPECT_EQ(9U, s->platform);
    // out-of-range fare / platform are rejected and leave the record untouched
    EXPECT_EQ(STATUS_ERR_RANGE, bst_update(&tree_, 7U, "Renamed", 99U, STATION_FARE_MAX + 1U, 9U, "Core"));
    EXPECT_EQ(STATUS_ERR_RANGE, bst_update(&tree_, 7U, "Renamed", 99U, 250U, 0U, "Core"));
    EXPECT_EQ(250U, bst_search(&tree_, 7U)->fare);
    EXPECT_EQ(9U, bst_search(&tree_, 7U)->platform);
}

TEST_F(BstTest, DeleteLeafOneChildTwoChildrenRoot)
{
    for (station_id_t id : {500U, 250U, 750U, 120U, 300U, 600U, 900U, 100U}) {
        ASSERT_EQ(STATUS_OK, add(id));
    }
    EXPECT_EQ(STATUS_OK, bst_delete(&tree_, 900U));  // leaf
    EXPECT_EQ(STATUS_OK, bst_delete(&tree_, 120U));  // one child (100)
    EXPECT_EQ(STATUS_OK, bst_delete(&tree_, 250U));  // two children
    EXPECT_EQ(STATUS_OK, bst_delete(&tree_, 500U));  // root
    EXPECT_EQ(STATUS_ERR_NOT_FOUND, bst_delete(&tree_, 500U));

    std::vector<station_id_t> out;
    ASSERT_EQ(STATUS_OK, bst_inorder(&tree_, collect_cb, &out));
    EXPECT_EQ((std::vector<station_id_t>{100, 300, 600, 750}), out);
    EXPECT_EQ(4U, tree_.count);
}

TEST_F(BstTest, StatsOnEmptyAndFilledTree)
{
    uint32_t count = 99U;
    station_id_t mn = 99U, mx = 99U;
    EXPECT_EQ(STATUS_ERR_EMPTY, bst_stats(&tree_, &count, &mn, &mx));
    ASSERT_EQ(STATUS_OK, add(40U));
    ASSERT_EQ(STATUS_OK, add(5U));
    ASSERT_EQ(STATUS_OK, add(80U));
    EXPECT_EQ(STATUS_OK, bst_stats(&tree_, &count, &mn, &mx));
    EXPECT_EQ(3U, count);
    EXPECT_EQ(5U, mn);
    EXPECT_EQ(80U, mx);
}

TEST_F(BstTest, NullArgumentsAreRejected)
{
    EXPECT_EQ(STATUS_ERR_NULL, bst_insert(nullptr, nullptr));
    EXPECT_EQ(nullptr, bst_search(nullptr, 1U));
    EXPECT_EQ(STATUS_ERR_NULL, bst_inorder(&tree_, nullptr, nullptr));
}

TEST_F(BstTest, CapacityLimit)
{
    for (station_id_t id = 1U; id <= BST_MAX_STATIONS; ++id) {
        ASSERT_EQ(STATUS_OK, add(id));
    }
    EXPECT_EQ(STATUS_ERR_FULL, add(BST_MAX_STATIONS + 1U));
}

}  // namespace
